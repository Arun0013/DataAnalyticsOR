function value = CART(a)

value = 2*a*(1-a);

