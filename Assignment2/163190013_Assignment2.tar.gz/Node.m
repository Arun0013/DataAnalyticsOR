classdef Node
	properties
		A;
		x;
		y;
		isLeaf;
		output;
		feature;
		threshold;
		leftChild;
		rightChild;
	end
end

		
	
