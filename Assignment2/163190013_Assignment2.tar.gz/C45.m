function value = C45(a)

value = -a*log(a) -(1-a)*log(1-a);

